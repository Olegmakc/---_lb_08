﻿namespace TextEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.te_menu = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_newFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_openFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_saveFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_saveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.menu_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_cut = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_copy = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_insert = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_word_wrap = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_font = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox_editor = new System.Windows.Forms.RichTextBox();
            this.status_path = new System.Windows.Forms.ToolStripStatusLabel();
            this.te_statusBar = new System.Windows.Forms.StatusStrip();
            this.te_cm_insert = new System.Windows.Forms.ToolStripMenuItem();
            this.te_menu.SuspendLayout();
            this.te_statusBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // te_menu
            // 
            this.te_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.настройкиToolStripMenuItem});
            this.te_menu.Location = new System.Drawing.Point(0, 0);
            this.te_menu.Name = "te_menu";
            this.te_menu.Size = new System.Drawing.Size(546, 24);
            this.te_menu.TabIndex = 0;
            this.te_menu.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_newFile,
            this.menu_openFile,
            this.menu_saveFile,
            this.menu_saveAs,
            this.toolStripMenuItem2,
            this.menu_exit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // menu_newFile
            // 
            this.menu_newFile.Name = "menu_newFile";
            this.menu_newFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.menu_newFile.Size = new System.Drawing.Size(172, 22);
            this.menu_newFile.Text = "&Создать";
            this.menu_newFile.Click += new System.EventHandler(this.te_menu_newFile_Click_1);
            // 
            // menu_openFile
            // 
            this.menu_openFile.Name = "menu_openFile";
            this.menu_openFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.menu_openFile.Size = new System.Drawing.Size(172, 22);
            this.menu_openFile.Text = "&Открыть";
            // 
            // menu_saveFile
            // 
            this.menu_saveFile.Enabled = false;
            this.menu_saveFile.Name = "menu_saveFile";
            this.menu_saveFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.menu_saveFile.Size = new System.Drawing.Size(172, 22);
            this.menu_saveFile.Text = "&Сохранить";
            // 
            // menu_saveAs
            // 
            this.menu_saveAs.Name = "menu_saveAs";
            this.menu_saveAs.Size = new System.Drawing.Size(172, 22);
            this.menu_saveAs.Text = "Сохранить &как ...";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(169, 6);
            // 
            // menu_exit
            // 
            this.menu_exit.Name = "menu_exit";
            this.menu_exit.Size = new System.Drawing.Size(172, 22);
            this.menu_exit.Text = "&Выход";
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_cut,
            this.menu_copy,
            this.menu_insert,
            this.toolStripMenuItem4});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "&Правка";
            // 
            // menu_cut
            // 
            this.menu_cut.Enabled = false;
            this.menu_cut.Name = "menu_cut";
            this.menu_cut.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.menu_cut.Size = new System.Drawing.Size(181, 22);
            this.menu_cut.Text = "Вырезать";
            // 
            // menu_copy
            // 
            this.menu_copy.Enabled = false;
            this.menu_copy.Name = "menu_copy";
            this.menu_copy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.menu_copy.Size = new System.Drawing.Size(181, 22);
            this.menu_copy.Text = "Копировать";
            // 
            // menu_insert
            // 
            this.menu_insert.Enabled = false;
            this.menu_insert.Name = "menu_insert";
            this.menu_insert.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.menu_insert.Size = new System.Drawing.Size(181, 22);
            this.menu_insert.Text = "Вставить";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(178, 6);
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_word_wrap,
            this.menu_font});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.настройкиToolStripMenuItem.Text = "Формат";
            // 
            // menu_word_wrap
            // 
            this.menu_word_wrap.Name = "menu_word_wrap";
            this.menu_word_wrap.Size = new System.Drawing.Size(183, 22);
            this.menu_word_wrap.Text = "Перенос по словам";
            // 
            // menu_font
            // 
            this.menu_font.Name = "menu_font";
            this.menu_font.Size = new System.Drawing.Size(183, 22);
            this.menu_font.Text = "Шриф";
            // 
            // textBox_editor
            // 
            this.textBox_editor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_editor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_editor.Enabled = false;
            this.textBox_editor.Location = new System.Drawing.Point(0, 24);
            this.textBox_editor.Name = "textBox_editor";
            this.textBox_editor.Size = new System.Drawing.Size(546, 316);
            this.textBox_editor.TabIndex = 3;
            this.textBox_editor.Text = "";
            // 
            // status_path
            // 
            this.status_path.Name = "status_path";
            this.status_path.Size = new System.Drawing.Size(36, 17);
            this.status_path.Text = "Шлях";
            // 
            // te_statusBar
            // 
            this.te_statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status_path});
            this.te_statusBar.Location = new System.Drawing.Point(0, 340);
            this.te_statusBar.Name = "te_statusBar";
            this.te_statusBar.Size = new System.Drawing.Size(546, 22);
            this.te_statusBar.SizingGrip = false;
            this.te_statusBar.TabIndex = 1;
            this.te_statusBar.Text = "statusStrip1";
            // 
            // te_cm_insert
            // 
            this.te_cm_insert.Enabled = false;
            this.te_cm_insert.Name = "te_cm_insert";
            this.te_cm_insert.Size = new System.Drawing.Size(180, 22);
            this.te_cm_insert.Text = "Вставить";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 362);
            this.Controls.Add(this.textBox_editor);
            this.Controls.Add(this.te_statusBar);
            this.Controls.Add(this.te_menu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.te_menu;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Текстовий редактор";
            this.TransparencyKey = System.Drawing.Color.Gray;
            this.te_menu.ResumeLayout(false);
            this.te_menu.PerformLayout();
            this.te_statusBar.ResumeLayout(false);
            this.te_statusBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip te_menu;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.RichTextBox textBox_editor;
        private System.Windows.Forms.ToolStripMenuItem menu_newFile;
        private System.Windows.Forms.ToolStripMenuItem menu_openFile;
        private System.Windows.Forms.ToolStripMenuItem menu_saveFile;
        private System.Windows.Forms.ToolStripMenuItem menu_exit;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem menu_saveAs;
        private System.Windows.Forms.ToolStripMenuItem menu_copy;
        private System.Windows.Forms.ToolStripMenuItem menu_cut;
        private System.Windows.Forms.ToolStripMenuItem menu_insert;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu_font;
        private System.Windows.Forms.ToolStripMenuItem menu_word_wrap;
        private System.Windows.Forms.ToolStripStatusLabel status_path;
        private System.Windows.Forms.StatusStrip te_statusBar;
        private System.Windows.Forms.ToolStripMenuItem te_cm_insert;
    }
}

