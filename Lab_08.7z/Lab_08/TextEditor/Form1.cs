﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class Form1 : Form
    {
        const string TITLE = "Текстовий редактор";
    
        const string PATH = "Шлях: ";
        public Form1()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            status_path.Text = PATH;

            menu_newFile.Click += Menu_newFile_Click;
            menu_openFile.Click += Menu_openFile_Click;         
            menu_saveFile.Click += Menu_saveFile_Click;
            menu_saveAs.Click += Menu_saveAs_Click;            

            menu_copy.Click += Menu_copy_Click;          
            menu_cut.Click += Menu_cut_Click;   
            menu_insert.Click += Menu_insert_Click;

            menu_exit.Click += Menu_exit_Click;
            menu_font.Click += Menu_font_Click;
            textBox_editor.SelectionChanged += TextBox_editor_SelectionChanged;
        }

    
        // Вихід з програми
       
        private void Menu_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

         
        // Зміна шрифта
      
        private void Menu_font_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();

            if (fd.ShowDialog() == DialogResult.OK)
            {
                textBox_editor.Font = fd.Font;
            }
        }
     
       // Вставити скопійований текст
       
        private void Menu_insert_Click(object sender, EventArgs e)
        {
            textBox_editor.Paste();
        }
   
        // Вирізати скопійований текст
        
        private void Menu_cut_Click(object sender, EventArgs e)
        {
            if (textBox_editor.SelectionLength > 0)
            {
                textBox_editor.Cut();
            }
        }
     
        // Копійовання виділеного тексту
        
        private void Menu_copy_Click(object sender, EventArgs e)
        {
            if (textBox_editor.SelectionLength > 0)
            { 
                textBox_editor.Copy();
            }
        }
     
        // Обробка виділення в редакторі
       
        private void TextBox_editor_SelectionChanged(object sender, EventArgs e)
        {
            if (textBox_editor.SelectionLength > 0)
            {
                menu_copy.Enabled = true;
                menu_cut.Enabled = true;
            }
            else
            {
                menu_copy.Enabled = false;
                menu_cut.Enabled = false;
            }
        }

        // Відкрити файл

        private void Menu_openFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Всі файли(*.*)|*.*|Текстові файли(*txt)|*.txt";
            openFileDialog.FilterIndex = 2;
            openFileDialog.Title = "Тестовий редактор :: Відкриття файла";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox_editor.Clear();

                string[] path = openFileDialog.FileName.Split('\\');
                this.Text = TITLE + $" :: {path[path.Length - 1]}";
                status_path.Text = "Шлях: " + openFileDialog.FileName;
                textBox_editor.Text = File.ReadAllText(openFileDialog.FileName);
                EnableDisableElements(true);
            }
        }

        // Створення нового файлу

        private void Menu_newFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Всі файли(*.*)|*.*|Текстові файли(*txt)|*.txt";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.Title = "Тестовий редактор :: Створення нового файла";
            saveFileDialog.FileName = "new_file";
            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.ValidateNames = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBox_editor.Clear();
                string[] path = saveFileDialog.FileName.Split('\\');
                this.Text = TITLE + $" :: {path[path.Length - 1]}";
                status_path.Text = "Шлях: " + saveFileDialog.FileName;
                StreamWriter sw = new StreamWriter(saveFileDialog.FileName, false, Encoding.Default);
                sw.Write("");
                sw.Close();

                EnableDisableElements(true);
            }
        }


        // Зберегти як ...

        private void Menu_saveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Всі файли(*.*)|*.*|Текстові файли(*txt)|*.txt";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.Title = "Тестовий редактор :: Зберегти файла як ...";
            saveFileDialog.FileName = "new_file";              
            saveFileDialog.DefaultExt = "txt";                
            saveFileDialog.ValidateNames = true;               

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string[] path = saveFileDialog.FileName.Split('\\');
                this.Text = TITLE + $" :: {path[path.Length - 1]}";
                status_path.Text = "Шлях: " + saveFileDialog.FileName;
                File.WriteAllText(saveFileDialog.FileName, textBox_editor.Text);
            }
        }

        // Закрити файл
       
        private void Menu_closeFile_Click(object sender, EventArgs e)
        {
            textBox_editor.Clear();
            EnableDisableElements(false);
        }
     
       
     
        // Збереження файлу
      
        private void Menu_saveFile_Click(object sender, EventArgs e)
        {
            File.WriteAllText(status_path.Text.Substring(6), textBox_editor.Text);
        }
    
       
        private void EnableDisableElements(bool status)
        {
            menu_saveFile.Enabled = status;
            textBox_editor.Enabled = status;
            menu_saveAs.Enabled = status;
            menu_insert.Enabled = status;
            te_cm_insert.Enabled = status;
            if (!status)
            {
                status_path.Text = PATH;
                this.Text = TITLE;
            }
        }

        private void te_menu_newFile_Click_1(object sender, EventArgs e)
        {

        }

        private void Menu_font_Click_1(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();

            if (fd.ShowDialog() == DialogResult.OK)
            {
                textBox_editor.Font = fd.Font;
            }
        }
    }
}
